%step 1: set the sample data, notice that all should be column vectors
x=[0.2772	0.2808	0.2708	0.2862	0.2809	0.2536	0.2737	0.2656	0.2809	0.271	0.2801	0.2831	0.2684	0.2807	0.2703	0.2792	0.2828	0.2529	0.28	0.2717 ]';
y=[0.0425	0.048	0.039	0.0226	0.0575	0.0489	0.0483	0.0493	0.0421	0.0512	0.0478	0.0475	0.0458	0.0473	0.0468	0.0443	0.0472	0.0416	0.0459	0.045 ]';
% step 2:set the parameters sigma , c, and remember to set the number for modelling
% 
sigma=0.3;
c=5;
n=15; % in my paper, I firstly choose the first 15 ones for modelling
% Step 3: run it with only one line 
[ ss mpes   mpep lambda a1  phi m   ] = simkgm1n( x,y,sigma,c,n );
plot([ss y])
legend('Predicted values','Observed values')


