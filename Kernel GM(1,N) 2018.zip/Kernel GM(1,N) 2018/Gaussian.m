function [ g ] = Gaussian( x,y,sigma )
%GAUSSIAN Summary of this function goes here
%   Detailed explanation goes here

g=exp(-sumsqr(x-y)/(2*power(sigma,2)));
end

